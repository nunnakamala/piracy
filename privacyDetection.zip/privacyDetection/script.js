class PiracyDetector {
    constructor() {
        this.form = document.getElementById('piracyForm');
        this.resultContainer = document.getElementById('result');
        this.initEventListeners();
    }

    initEventListeners() {
        this.form.addEventListener('submit', this.handleSubmit.bind(this));
    }

    async handleSubmit(event) {
        event.preventDefault();
        this.clearResults();

        // Display loading message
        this.resultContainer.innerHTML = `<p>Loading...</p>`;
        this.resultContainer.className = 'result-container';

        const url = document.getElementById('urlInput').value;
        const keyword = document.getElementById('keywordInput').value;

        try {
            const content = await this.fetchWebContent(url);
            this.analyzeContent(content, keyword, url);
        } catch (error) {
            this.displayError(error.message);
        }
    }

    async fetchWebContent(url) {
        try {
            // Use AllOrigins as the proxy
            const proxyUrl = `https://api.allorigins.win/raw?url=${encodeURIComponent(url)}`;
            const response = await fetch(proxyUrl);

            if (!response.ok) {
                throw new Error('Failed to fetch webpage');
            }

            return await response.text();
        } catch (error) {
            throw new Error('Unable to retrieve webpage content');
        }
    }

    analyzeContent(content, keyword, url) {
        const normalizedContent = content.toLowerCase();
        const normalizedKeyword = keyword.toLowerCase();

        const strategies = [
            normalizedContent.includes(normalizedKeyword),
            this.calculateKeywordDensity(normalizedContent, normalizedKeyword) > 0.01
        ];

        const isPiracy = strategies.some(result => result);
        this.displayResult(isPiracy, url, keyword);
    }

    calculateKeywordDensity(content, keyword) {
        const words = content.split(/\s+/);
        const keywordCount = (content.match(new RegExp(keyword, 'g')) || []).length;
        return keywordCount / words.length;
    }

    displayResult(isPiracy, url, keyword) {
        this.clearResults();

        const resultElement = this.resultContainer;

        if (isPiracy) {
            resultElement.innerHTML = `
                <h3>⚠️ Potential Piracy Detected!</h3>
                <p>Suspicious content found for keyword: <strong>${keyword}</strong></p>
                <p>URL: ${url}</p>
            `;
            resultElement.classList.add('result-warning');
        } else {
            resultElement.innerHTML = `
                <h3>✅ No Suspicious Content</h3>
                <p>No matches found for keyword: <strong>${keyword}</strong></p>
            `;
            resultElement.classList.add('result-success');
        }
    }

    displayError(message) {
        this.clearResults();

        const resultElement = this.resultContainer;
        resultElement.innerHTML = `
            <h4>Error</h4>
            <p>${message}</p>
        `;
        resultElement.classList.add('result-error');
    }

    clearResults() {
        this.resultContainer.innerHTML = '';
        this.resultContainer.className = 'result-container';
    }
}

// Initialize the Piracy Detector
new PiracyDetector();
